File Descriptions:
X16-Pi-Shield.GBL - Bottom Copper Layer                        
X16-Pi-Shield.GBO - Bottom Silkscreen/Overlay
X16-Pi-Shield.GBS - Bottom Solder Mask
X16-Pi-Shield.GBP - Bottom Paste Mask
X16-Pi-Shield.GTL - Top Copper Layer
X16-Pi-Shield.GTO - Top Silkscreen/Overlay
X16-Pi-Shield.GTS - Top Solder Mask
X16-Pi-Shield.GTP - Top Paste Mask
X16-Pi-Shield.GKO - Keep Out Layer(Board Outline)
X16-Pi-Shield.XLN - Excellon Drill File

Contact Information:
Name: Minh Nguyen
Email (Preferred): nguye599@purdue.edu
Phone: 4059079922